from pathlib import Path
import base64,gzip,re
root=Path(__file__).resolve().parent
assets={'/'+str(f.relative_to(root/'server_static')):base64.b64encode(gzip.compress(f.read_bytes(),mtime=0)).decode() for f in (root/'server_static').rglob('*') if f.is_file()}
p=root/'server.py';s=p.read_text();s=re.sub(r'^EMBEDDED_UI = .*$',lambda _: 'EMBEDDED_UI = '+repr(assets),s,flags=re.M);p.write_text(s)
