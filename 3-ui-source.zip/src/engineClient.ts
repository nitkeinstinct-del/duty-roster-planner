// Types shared with the Python engine (public/roster_engine.py) + the server client.
// On this branch there is NO browser-side solver: every roster is computed by the
// Python engine running on the server (see server.py, endpoint POST /api/solve).

export type Person = { name: string; leave: number[] };
export type Task = { name: string; req: number; from: number; to: number; days?: number[]; shiftLen: number; restBefore?: number; restAfter?: number };
export type Config = {
    days: number;
    minRest: number;
    comfortRest: number;
    balance: number;
    firstWeekday: number;
    weekendDays: number[];
    seed: number;
    iterations: number;
};
export type Slot = { id: number; day: number; task: number; start: number; end: number; weekend: boolean };
export type Stats = { name: string; shifts: number; hours: number; nights: number; weekendHours: number; target: number; minGap: number | null; leaveDays: number };
export type Feasibility = 'full' | 'proven-infeasible' | 'not-found';
export type Result = { feasibility: Feasibility; reason: string; minRestUsed: number; slots: Slot[]; assign: number[][]; uncovered: number; violations: string[]; stats: Stats[]; cost: number; engine?: string };

export const defaultConfig: Config = { days: 14, minRest: 8, comfortRest: 24, balance: 0.4, firstWeekday: 0, weekendDays: [5, 6], seed: 1, iterations: 40000 };

type Payload = { cfg: Config; people: Person[]; tasks: Task[]; maxRest: boolean };

/** Solve on the server (POST /api/solve). There is deliberately no browser-side fallback on
    this branch. The free server instance may be asleep; the first request then waits while it
    starts (about a minute), so the timeout is generous. */
export function solveOnServer(payload: Payload, onStatus: (s: string) => void): Promise<Result> {
    onStatus('שולח את הקלט לשרת לחישוב (אם השרת במצב שינה, ההפעלה עלולה לקחת כדקה)...');
    const ctrl = new AbortController();
    const timer = setTimeout(() => ctrl.abort(), 150000);
    return fetch('/api/solve', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload),
        signal: ctrl.signal,
    }).then(async (resp) => {
        clearTimeout(timer);
        const text = await resp.text();
        let data: (Result & { error?: string }) | null = null;
        try { data = text ? JSON.parse(text) : null; } catch { data = null; }
        if (!resp.ok) throw new Error((data && data.error) || `השרת החזיר שגיאה (HTTP ${resp.status})`);
        if (!data || data.engine !== 'python-server') throw new Error('התשובה מהשרת לא תקינה (חסר סימון מנוע פייתון בשרת)');
        onStatus('מעבד את התוצאה...');
        return data as Result;
    }).catch((e) => {
        clearTimeout(timer);
        if (e && e.name === 'AbortError') throw new Error('השרת לא ענה בזמן. שירות האירוח החינמי נרדם כשאין תנועה ומתעורר כדקה - נסו שוב.');
        throw e instanceof Error ? e : new Error('החיבור לשרת נכשל');
    });
}
