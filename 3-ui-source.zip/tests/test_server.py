import copy,json,sys,unittest,threading,urllib.request,urllib.error
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import server

class APITests(unittest.TestCase):
 def setUp(self):
  self.d={'cfg':server.roster_engine.default_config(),'people':[{'name':'fictional','leave':[]}], 'tasks':[{'name':'example','req':1,'from':0,'to':24,'shiftLen':8}], 'maxRest':True}
 def test_valid(self): self.assertEqual(server.validate_payload(self.d)[0],200)
 def test_reject_bad_shapes(self):
  for d in [None,[],{}, {'maxRest':'yes'}]:self.assertEqual(server.validate_payload(d)[0],400)
 def test_reject_bad_values_without_truncation(self):
  for field,value in [('days',1.5),('days',32),('iterations',80001),('balance',float('nan')),('minRest',True)]:
   d=copy.deepcopy(self.d);d['cfg'][field]=value;self.assertEqual(server.validate_payload(d)[0],400)
 def test_dates_names_and_task(self):
  for mutate in [lambda d:d['people'][0].update(name='x'*61),lambda d:d['people'][0].update(leave=[99]),lambda d:d['tasks'][0].update(req=1.5),lambda d:d['tasks'][0].update(days='bad'),lambda d:d['tasks'][0].update(shiftLen=.01)]:
   d=copy.deepcopy(self.d);mutate(d);self.assertEqual(server.validate_payload(d)[0],400)
 def test_server_http(self):
  srv=server.ThreadingHTTPServer(('127.0.0.1',0),server.Handler);t=threading.Thread(target=srv.serve_forever,daemon=True);t.start();url='http://127.0.0.1:'+str(srv.server_port)
  try:
   self.assertEqual(json.load(urllib.request.urlopen(url+'/api/health'))['engine'],'python-server')
   with urllib.request.urlopen(url+'/') as r:self.assertIn(b'<html',r.read());self.assertEqual(r.headers['Cache-Control'],'no-store')
   for path in ['/nope','/../server.py','/server.py']:
    with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(url+path)
    self.assertEqual(e.exception.code,404)
   with self.assertRaises(urllib.error.HTTPError) as e:urllib.request.urlopen(urllib.request.Request(url+'/api/solve',data=b'bad'))
   self.assertEqual(e.exception.code,400)
  finally:srv.shutdown();srv.server_close();t.join()
if __name__=='__main__':unittest.main()
